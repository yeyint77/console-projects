package atm.app;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Map.Entry;
import java.util.Scanner;

public class OptionMenu extends Account {

	Scanner input = new Scanner(System.in);
	DecimalFormat moneyFormat = new DecimalFormat("'$'###,##0.00");
	HashMap<Integer, Integer> data = new HashMap<Integer, Integer>();
	int selection;
	
	public void getLogin() throws IOException{
		
		int x = 1;
		data.put(989504852, 1234);
		showTitle("Welcome to ATM Project");
		breakLine();
			
		do {
			
			try {			
				System.out.print("Enter Your Account Number: ");
				setAccountNumber(input.nextInt());
				
				System.out.print("Enter Your Pin Number: ");
				setPinNumber(input.nextInt());
				breakLine();								
			} catch (InputMismatchException e) {
				// TODO: handle exception
				System.out.println("\n" + "Invalid Character(s). Only Numbers." + "\n");
//				input.nextLine();
//				x = 2;
			}			
			for(Entry<Integer, Integer> entry : data.entrySet()) {
				
				if(entry.getKey() == getAccountNumber() && entry.getValue() == getPinNumber()) {
					getAccountType();
					return;
				}
			}				
			System.out.println("\n" + "Wrong Account Number or Pin Number" + "\n");			
		} while (x == 1);
		
			
	}
	
	public void getAccountType() {
//		System.out.println("Yayy");
		
		showMessage("ခ့ခခChoose Account Type");
		breakLine();
		System.out.println("Type 1 - Checking Account");
		System.out.println("Type 2 - Saving Account");
		System.out.println("Type 3 - Exit");
		System.out.print("Choice: ");
		selection = input.nextInt();
		
		switch(selection) {
		case 1 :
			showMessage("Checking Account");
			getChecking();
			break;
			
		case 2 :
			showMessage("Saving Account");
			getSaving();
			break;
		
		case 3 :
			System.out.println("Thank you for using our ATM,Have a nice day Sir!!");
			break;
			
		default :
			System.out.println("\n" + "Invalid Number,Please try again" + "\n");
			getAccountType();
		}	
	}
	
	public void getChecking() {
//		System.out.println("Hey this is checking account");
		System.out.println("Type 1 - View Checking Balance");
		System.out.println("Type 2 - Deposit Funds");
		System.out.println("Type 3 - Withdraw Funds");
		System.out.println("Type 4 - Back");
		System.out.print("Choice: ");
		selection = input.nextInt();
		
		switch(selection) {
		case 1 :
			System.out.println("Your checking account balance is: " + moneyFormat.format(getCheckingBalance()));
			getChecking();
			break;
		
		case 2 :
			getCheckingDeposit();
			getChecking();
			break;
		
		case 3 :
			getCheckingWithdraw();
			getChecking();
			break;
		
		case 4 :
			getAccountType();
			break;
			
		default :
			System.out.println("\n" + "Invalid Number,Please try again" + "\n");
			getChecking();
		}
			
	}
	
	public void getSaving() {
//		System.out.println("Hey this is saving account");
		System.out.println("Type 1 - View Saving Balance");
		System.out.println("Type 2 - Deposit Funds");
		System.out.println("Type 3 - Withdraw Funds");
		System.out.println("Type 4 - Exit");
		System.out.print("Choice: ");
		selection = input.nextInt();
		
		switch(selection) {
		case 1 :
			System.out.println("Your saving account balance is: " + moneyFormat.format(getSavingBalance()));
			getSaving();
			break;
		
		case 2 :
			getSavingDeposit();
			getSaving();
			break;
		
		case 3 :
			getSavingWithdraw();
			getSaving();
			break;
		
		case 4 :
			getAccountType();
			break;
			
		default :
			System.out.println("\n" + "Invalid Number,Please try again" + "\n");
			getSaving();
		}
	}
	
	void showTitle(String message) {
		
		String star = "";
		
		for(int i = 0; i < message.length(); i++) {
			star += "@";
		}
		
		System.out.println("@@%s@@".formatted(star));
		System.out.println("@ %s @".formatted(message));
		System.out.println("@@%s@@".formatted(star));
		
	}
	
		void showMessage(String message) {
		
		String star = "";
		
		for(int i = 0; i < message.length(); i++) {
			star += "*";
		}
		
		System.out.println("**%s**".formatted(star));
		System.out.println("* %s *".formatted(message));
		System.out.println("**%s**".formatted(star));
		
	}
	
	void breakLine() {
		System.out.println();
	}
	
}
