package atm.app;

import java.text.DecimalFormat;
import java.util.Scanner;

public class Account {
	
	private int accountNumber;
	private int pinNumber;
	private double checkingBalance;
	private double savingBalance;
	
	DecimalFormat moneyFormat = new DecimalFormat("'$'###,##0.00");
	Scanner input = new Scanner(System.in);
	
	public int getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}
	public int getPinNumber() {
		return pinNumber;
	}
	public void setPinNumber(int pinNumber) {
		this.pinNumber = pinNumber;
	}
	public double getCheckingBalance() {
		return checkingBalance;
	}
	public void setCheckingBalance(double checkingBalance) {
		this.checkingBalance = checkingBalance;
	}
	public double getSavingBalance() {
		return savingBalance;
	}
	public void setSavingBalance(double savingBalance) {
		this.savingBalance = savingBalance;
	}

	public double calcCheckingDeposit(double amount) {
		checkingBalance = (checkingBalance + amount);
		return checkingBalance;
	}
	
	public double calcCheckingWithdraw(double amount) {
		checkingBalance = (checkingBalance - amount);
		return savingBalance;
	}
	
	public void getCheckingDeposit() {
		System.out.println("Your checking account balance is: " + moneyFormat.format(checkingBalance));
		System.out.print("Amount you want to deposit to your checking account: ");
		double amount = input.nextDouble();
		
		if((checkingBalance + amount) >= 0) {
			calcCheckingDeposit(amount);
			System.out.println("Your new checking account balance is: " + moneyFormat.format(checkingBalance));
		}else {
			System.out.println("\n" + "Balance cannot be negative");
		}
		
	}
	
	public void getCheckingWithdraw() {
		System.out.println("Your checking account balance is: " + moneyFormat.format(checkingBalance));
		System.out.print("Amount you want to withdraw from your checking account: ");
		double amount = input.nextDouble();
		
		if((checkingBalance - amount) >= 0) {
			calcCheckingDeposit(amount);
			System.out.println("Your new checking account balance is: " + moneyFormat.format(checkingBalance));
		}else {
			System.out.println("\n" + "Balance cannot be negative");
		}
		
	}
	
	public void getSavingDeposit() {
		System.out.println("Your saving account balance is: " + moneyFormat.format(savingBalance));
		System.out.print("Amount you want to deposit to your saving account: ");
		double amount = input.nextDouble();
		
		if((savingBalance + amount) >= 0) {
			calcCheckingDeposit(amount);
			System.out.println("Your new saving account balance is: " + moneyFormat.format(savingBalance));
		}else {
			System.out.println("\n" + "Balance cannot be negative");
		}
		
	}
	
	public void getSavingWithdraw() {
		System.out.println("Your saving account balance is: " + moneyFormat.format(savingBalance));
		System.out.print("Amount you want to withdraw from your saving account: ");
		double amount = input.nextDouble();
		
		if((savingBalance - amount) >= 0) {
			calcCheckingDeposit(amount);
			System.out.println("Your new saving account balance is: " + moneyFormat.format(savingBalance));
		}else {
			System.out.println("\n" + "Balance cannot be negative");
		}
		
	}
	

}
